<?php wp_head() ?>
<h1> Hey ,Some Test </h1>
<?php wp_footer() ?>
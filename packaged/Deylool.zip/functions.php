<?php

require get_template_directory(). './inc/scripts-style.php';
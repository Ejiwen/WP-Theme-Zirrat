function helloMe(name) {
    console.log("Hey! ... hello "+name);
}

export default helloMe;
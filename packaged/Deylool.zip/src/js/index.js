import helloMe from "./scripts/helloMe"

console.log("Hello World ");

helloMe("cheikhany");